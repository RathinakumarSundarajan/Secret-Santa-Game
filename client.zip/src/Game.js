import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Papa from 'papaparse';  // Import papaparse for CSV generation
import './Game.css';  // Import the CSS file

function Game() {
    const [file, setFile] = useState(null);
    const [participants, setParticipants] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [previousPairings, setPreviousPairings] = useState({});  // Store previous pairings

    useEffect(() => {
        // Make GET request to fetch data from /generateCSV endpoint
        axios.get('http://localhost:5000/api/generateCSV')
          .then((response) => {
            console.log('Participants data:', response.data); // Log the data to the console
            setParticipants(response.data);  // Store the participants data in state
            setLoading(false);  // Set loading to false once the data is fetched
          })
          .catch((error) => {
            console.error('Error fetching data:', error);
            setError('Error fetching participants data');
            setLoading(false);  // Stop loading even if there is an error
          });

        // Fetch the previous year’s pairings (if available)
        axios.get('http://localhost:5000/api/previousPairings')
          .then((response) => {
            setPreviousPairings(response.data);  // Store previous pairings
          })
          .catch((error) => {
            console.error('Error fetching previous pairings:', error);
            setPreviousPairings({});
          });
    }, []);  // Empty dependency array means this runs once when the component mounts

    // Handle file input change
    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    // Handle file upload (to a server endpoint, if necessary)
    const handleUpload = async () => {
        const formData = new FormData();
        formData.append('file', file);

        try {
            await axios.post('http://localhost:5000/api/upload', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            alert('CSV file uploaded successfully');
            window.location.reload();
        } catch (err) {
            console.error(err);
            alert('Failed to upload file');
        }
    };

    // Function to generate CSV for the Secret Santa game
    const generateCSV = () => {
        // Shuffle the participants array for random pairing
        const shuffledParticipants = [...participants];
        for (let i = shuffledParticipants.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffledParticipants[i], shuffledParticipants[j]] = [shuffledParticipants[j], shuffledParticipants[i]];
        }

        // Map over the participants to generate Secret Santa pairs
        const secretSantaData = participants.map((participant, index) => {
            // Find a random participant for the child, avoiding self-pairing and previous year’s pairing
            let child = shuffledParticipants[index];
            while (
                child.Employee_Name === participant.Employee_Name ||  // Avoid self-pairing
                previousPairings[participant.Employee_Name] === child.Employee_Name // Avoid previous year's pairing
            ) {
                // If the participant gets assigned to themselves or repeats last year's pairing, reshuffle
                const randomIndex = Math.floor(Math.random() * shuffledParticipants.length);
                child = shuffledParticipants[randomIndex];
            }

            // Update previous pairings for the next year (this will be used to check the following year)
            const updatedPreviousPairings = { ...previousPairings, [participant.Employee_Name]: child.Employee_Name };

            // After valid pairing, update the state to reflect the new pairings for future reference
            setPreviousPairings(updatedPreviousPairings);

            return {
                Employee_Name: participant.Employee_Name,
                Employee_EmailID: participant.Employee_EmailID,
                Employee_Child_Name: child.Employee_Name, // Child's Name
                Employee_Child_EmailID: child.Employee_EmailID, // Child's Email
            };
        });

        // Use papaparse to convert the data into CSV format
        const csv = Papa.unparse(secretSantaData);

        // Create a downloadable link for the CSV file
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);

        link.setAttribute('href', url);
        link.setAttribute('download', 'secret_santa.csv');
        document.body.appendChild(link);
        link.click();  // Trigger the download
        document.body.removeChild(link);  // Clean up the link
    };

    // Display loading or error state
    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>{error}</div>;
    }

    return (
        <div className="game-container">
            <h2 className="title">Secret Santa Game</h2>
            <div className="input-section">
                <input type="file" accept=".csv" onChange={handleFileChange} className="file-input" />
                <button onClick={handleUpload} className="upload-button">Upload CSV</button>
            </div>
            <button onClick={generateCSV} className="generate-button">Generate Secret Santa CSV</button>
        </div>
    );
}

export default Game;









































// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import Papa from 'papaparse';  // Import papaparse for CSV generation

// function Game() {
//     const [file, setFile] = useState(null);
//     const [participants, setParticipants] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);
//     const [previousPairings, setPreviousPairings] = useState({});  // Store previous pairings

//     useEffect(() => {
//         // Make GET request to fetch data from /generateCSV endpoint
//         axios.get('http://localhost:5000/generateCSV')
//           .then((response) => {
//             console.log('Participants data:', response.data); // Log the data to the console
//             setParticipants(response.data);  // Store the participants data in state
//             setLoading(false);  // Set loading to false once the data is fetched
//           })
//           .catch((error) => {
//             console.error('Error fetching data:', error);
//             setError('Error fetching participants data');
//             setLoading(false);  // Stop loading even if there is an error
//           });

//         // Fetch the previous year’s pairings (if available)
//         axios.get('http://localhost:5000/previousPairings')
//           .then((response) => {
//             setPreviousPairings(response.data);  // Store previous pairings
//           })
//           .catch((error) => {
//             console.error('Error fetching previous pairings:', error);
//             setPreviousPairings({});
//           });
//     }, []);  // Empty dependency array means this runs once when the component mounts

//     // Handle file input change
//     const handleFileChange = (e) => {
//         setFile(e.target.files[0]);
//     };

//     // Handle file upload (to a server endpoint, if necessary)
//     const handleUpload = async () => {
//         const formData = new FormData();
//         formData.append('file', file);

//         try {
//             await axios.post('http://localhost:5000/upload', formData, {
//                 headers: { 'Content-Type': 'multipart/form-data' }
//             });
//             alert('CSV file uploaded successfully');
//         } catch (err) {
//             console.error(err);
//             alert('Failed to upload file');
//         }
//     };

//     // Function to generate CSV for the Secret Santa game
//     const generateCSV = () => {
//         // Shuffle the participants array for random pairing
//         const shuffledParticipants = [...participants];
//         for (let i = shuffledParticipants.length - 1; i > 0; i--) {
//             const j = Math.floor(Math.random() * (i + 1));
//             [shuffledParticipants[i], shuffledParticipants[j]] = [shuffledParticipants[j], shuffledParticipants[i]];
//         }

//         // Map over the participants to generate Secret Santa pairs
//         const secretSantaData = participants.map((participant, index) => {
//             // Find a random participant for the child, avoiding self-pairing and previous year’s pairing
//             let child = shuffledParticipants[index];
//             while (
//                 child.Employee_Name === participant.Employee_Name ||  // Avoid self-pairing
//                 previousPairings[participant.Employee_Name] === child.Employee_Name // Avoid previous year's pairing
//             ) {
//                 // If the participant gets assigned to themselves or repeats last year's pairing, reshuffle
//                 const randomIndex = Math.floor(Math.random() * shuffledParticipants.length);
//                 child = shuffledParticipants[randomIndex];
//             }

//             // Update previous pairings for the next year (this will be used to check the following year)
//             const updatedPreviousPairings = { ...previousPairings, [participant.Employee_Name]: child.Employee_Name };

//             // After valid pairing, update the state to reflect the new pairings for future reference
//             setPreviousPairings(updatedPreviousPairings);

//             return {
//                 Employee_Name: participant.Employee_Name,
//                 Employee_EmailID: participant.Employee_EmailID,
//                 Employee_Child_Name: child.Employee_Name, // Child's Name
//                 Employee_Child_EmailID: child.Employee_EmailID, // Child's Email
//             };
//         });

//         // Use papaparse to convert the data into CSV format
//         const csv = Papa.unparse(secretSantaData);

//         // Create a downloadable link for the CSV file
//         const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
//         const link = document.createElement('a');
//         const url = URL.createObjectURL(blob);

//         link.setAttribute('href', url);
//         link.setAttribute('download', 'secret_santa.csv');
//         document.body.appendChild(link);
//         link.click();  // Trigger the download
//         document.body.removeChild(link);  // Clean up the link
//     };

//     // Display loading or error state
//     if (loading) {
//         return <div>Loading...</div>;
//     }

//     if (error) {
//         return <div>{error}</div>;
//     }

//     return (
//         <div>
//             <h2>Secret Santa Game</h2>
//             <input type="file" accept=".csv" onChange={handleFileChange} />
//             <button onClick={handleUpload}>Upload CSV</button>
            
//             {/* Button to generate and download the Secret Santa CSV */}
//             <button onClick={generateCSV}>Generate Secret Santa CSV</button>
//         </div>
//     );
// }

// export default Game;















































// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import Papa from 'papaparse';  // Import papaparse for CSV generation

// function Game() {
//     const [file, setFile] = useState(null);
//     const [participants, setParticipants] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     useEffect(() => {
//         // Make GET request to the backend to fetch data from /generateCSV endpoint
//         axios.get('http://localhost:5000/generateCSV')
//           .then((response) => {
//             console.log('Participants data:', response.data); // Log the data to the console
//             setParticipants(response.data);  // Store the participants data in state
//             setLoading(false);  // Set loading to false once the data is fetched
//           })
//           .catch((error) => {
//             console.error('Error fetching data:', error);
//             setError('Error fetching participants data');
//             setLoading(false);  // Stop loading even if there is an error
//           });
//     }, []);  // Empty dependency array means this runs once when the component mounts

//     // Handle file input change
//     const handleFileChange = (e) => {
//         setFile(e.target.files[0]);
//     };

//     // Handle file upload (to a server endpoint, if necessary)
//     const handleUpload = async () => {
//         const formData = new FormData();
//         formData.append('file', file);

//         try {
//             await axios.post('http://localhost:5000/upload', formData, {
//                 headers: { 'Content-Type': 'multipart/form-data' }
//             });
//             alert('CSV file uploaded successfully');
//         } catch (err) {
//             console.error(err);
//             alert('Failed to upload file');
//         }
//     };

//     // Function to generate CSV for the Secret Santa game
//     const generateCSV = () => {
//         const secretSantaData = participants.map((participant) => {
//             const { Employee_Name, Employee_EmailID } = participant;
//             // Generate Secret Santa child name and email
//             const Employee_Child_Name = `${Employee_Name} Child`;
//             const Employee_Child_EmailID = `${Employee_EmailID.split('@')[0]}.child@domain.com`;

//             return {
//                 Employee_Name,
//                 Employee_EmailID,
//                 Employee_Child_Name,
//                 Employee_Child_EmailID,
//             };
//         });

//         // Use papaparse to convert the data into CSV format
//         const csv = Papa.unparse(secretSantaData);

//         // Create a downloadable link for the CSV file
//         const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
//         const link = document.createElement('a');
//         const url = URL.createObjectURL(blob);

//         link.setAttribute('href', url);
//         link.setAttribute('download', 'secret_santa.csv');
//         document.body.appendChild(link);
//         link.click();  // Trigger the download
//         document.body.removeChild(link);  // Clean up the link
//     };

//     // Display loading or error state
//     if (loading) {
//         return <div>Loading...</div>;
//     }

//     if (error) {
//         return <div>{error}</div>;
//     }

//     return (
//         <div>
//             <h2>Secret Santa Game</h2>
//             <input type="file" accept=".csv" onChange={handleFileChange} />
//             <button onClick={handleUpload}>Upload CSV</button>
            
//             {/* Button to generate and download the Secret Santa CSV */}
//             <button onClick={generateCSV}>Generate Secret Santa CSV</button>

//             <h2>Participants List</h2>
//             <table>
//                 <thead>
//                     <tr>
//                         <th>Employee Name</th>
//                         <th>Employee Email ID</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     {participants.map((participant, index) => (
//                         <tr key={index}>
//                             <td>{participant.Employee_Name}</td>
//                             <td>{participant.Employee_EmailID}</td>
//                         </tr>
//                     ))}
//                 </tbody>
//             </table>
//         </div>
//     );
// }

// export default Game;


































// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// function Game() {
//     const [file, setFile] = useState(null);


//     const [participants, setParticipants] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);





//     const handleFileChange = (e) => {
//         setFile(e.target.files[0]);
//     };

//     const handleUpload = async () => {
//         const formData = new FormData();
//         formData.append('file', file);

//         try {
//             await axios.post('http://localhost:5000/upload', formData, {
//                 headers: { 'Content-Type': 'multipart/form-data' }
//             });
//             alert('CSV file uploaded successfully');
//         } catch (err) {
//             console.error(err);
//             alert('Failed to upload file');
//         }
//     };





//     useEffect(() => {
//         // Make GET request to the backend to fetch data from /generateCSV endpoint
//         axios.get('http://localhost:5000/generateCSV')
//           .then((response) => {
//             console.log('Participants data:', response.data); // Log the data to the console
//             setParticipants(response.data);  // Store the participants data in state
//             setLoading(false);  // Set loading to false once the data is fetched
//           })
//           .catch((error) => {
//             console.error('Error fetching data:', error);
//             setError('Error fetching participants data');
//             setLoading(false);  // Stop loading even if there is an error
//           });
//       }, []);  // Empty dependency array means this runs once when the component mounts
    
//       if (loading) {
//         return <div>Loading...</div>;
//       }
    
//       if (error) {
//         return <div>{error}</div>;
//       }










//     return (
//         <div>
//             <h2>Secret Santa Game</h2>
//             <input type="file" accept=".csv" onChange={handleFileChange} />
//             <button onClick={handleUpload}>Upload CSV</button>
//             {/* <button onClick={downloadCSV}>Download CSV</button> */}



//             <h2>Participants List</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>Employee Name</th>
//             <th>Employee Email ID</th>
//           </tr>
//         </thead>
//         <tbody>
//           {participants.map((participant, index) => (
//             <tr key={index}>
//               <td>{participant.Employee_Name}</td>
//               <td>{participant.Employee_EmailID}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>

//         </div>
//     );
// }

// export default Game;
