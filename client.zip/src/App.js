import React from 'react'


import Game from './Game'

const App = () => {
  return (
    <>
    <Game/>
    </>

    
  )
}

export default App




