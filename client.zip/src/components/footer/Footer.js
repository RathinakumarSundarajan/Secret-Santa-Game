import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="app-footer">
      <div className="app-footer__content">
        <div className="app-footer__column app-footer__about">
          <h3 className="app-footer__heading">About Us</h3>
          <p className="app-footer__text">
            Welcome to our company! We are leaders in delivering top-notch services and cutting-edge solutions tailored to your needs. 
            Our team is fueled by a passion for innovation and a relentless pursuit of excellence. 
            We believe in building lasting relationships with our clients, driven by trust, transparency, and a shared vision for success.
          </p>
        </div>
        <div className="app-footer__column app-footer__contact">
          <h3 className="app-footer__heading">Contact Us</h3>
          <p className="app-footer__text">
            We’re here to assist you! Reach out to us via any of the following methods:
            <br />Email: <a href="mailto:contact@example.com">contact@example.com</a>
            <br />Phone: <a href="tel:+1234567890">(123) 456-7890</a>
            <br />Address: 123 Main Street, Anytown, USA
          </p>
        </div>
        <div className="app-footer__column app-footer__social">
          <h3 className="app-footer__heading">Follow Us</h3>
          <p className="app-footer__text">Stay connected with us through our social media channels:</p>
          <ul className="app-footer__social-list">
            <li className="app-footer__social-item"><a href="#" className="app-footer__social-link">Facebook</a></li>
            <li className="app-footer__social-item"><a href="#" className="app-footer__social-link">Twitter</a></li>
            <li className="app-footer__social-item"><a href="#" className="app-footer__social-link">Instagram</a></li>
            <li className="app-footer__social-item"><a href="#" className="app-footer__social-link">LinkedIn</a></li>
            <li className="app-footer__social-item"><a href="#" className="app-footer__social-link">YouTube</a></li>
          </ul>
        </div>
        <div className="app-footer__column app-footer__links">
          <h3 className="app-footer__heading">Quick Links</h3>
          <p className="app-footer__text">Explore our site:</p>
          <ul className="app-footer__links-list">
            <li className="app-footer__links-item"><a href="#" className="app-footer__links-link">Home</a></li>
            <li className="app-footer__links-item"><a href="#" className="app-footer__links-link">Services</a></li>
            <li className="app-footer__links-item"><a href="#" className="app-footer__links-link">About</a></li>
            <li className="app-footer__links-item"><a href="#" className="app-footer__links-link">Contact</a></li>
            <li className="app-footer__links-item"><a href="#" className="app-footer__links-link">Blog</a></li>
            <li className="app-footer__links-item"><a href="#" className="app-footer__links-link">Careers</a></li>
          </ul>
        </div>
      </div>
      <div className="app-footer__bottom">
        <p className="app-footer__text">&copy; 2024 Your Company. All rights reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
      </div>
    </footer>
  );
};

export default Footer;
