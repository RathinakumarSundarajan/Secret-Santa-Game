const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse');
const db = require('../database/dbconnection'); // Database connection
const multer = require('multer');

// Set up multer storage for CSV file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// API to upload CSV and store data in MySQL
exports.uploadCSVFile = async (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

  const filePath = req.file.path;

  // Read and parse the CSV file
  const results = [];
  fs.createReadStream(filePath)
    .pipe(parse({ columns: true, trim: true }))  // Parse the CSV file with headers
    .on('data', (row) => {
      console.log('Parsed row:', row);  // Log row data for debugging
      results.push(row);
    })
    .on('end', () => {
      // Insert data into MySQL
      results.forEach((row) => {
        const { Employee_Name, Employee_EmailID } = row;  // Use the correct field names here

        if (!Employee_Name || !Employee_EmailID) {
          console.error('Missing required fields in row:', row);
          return; // Skip rows with missing data
        }

        const query = 'INSERT INTO participants (Employee_Name, Employee_EmailID) VALUES (?, ?)';
        db.query(query, [Employee_Name, Employee_EmailID], (err, result) => {
          if (err) {
            console.error('Error inserting row:', err);
          } else {
            console.log('Inserted row:', result);
          }
        });
      });

      res.send('File uploaded and data saved to database.');
    })
    .on('error', (err) => {
      res.status(500).send('Error reading CSV file.');
    });
};

// API to generate and get CSV data
exports.getCSVFile = async (req, res) => {
  const query = 'SELECT * FROM participants';

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching participants:', err);
      return res.status(500).send('Error fetching data from database.');
    }

    // Log the results to the console
    console.log('Participants data:', results);

    // Optionally, you can return the results in the response to the client
    res.json(results);
  });
};

module.exports.upload = upload; // Export multer configuration for use in router




























// const express = require('express');
// const cors = require('cors');
// const bodyParser = require('body-parser');
// const mysql = require('mysql');
// const multer = require('multer');
// const fs = require('fs');
// const path = require('path');
// const {parse} = require('csv-parse'); // Correctly importing the CSV parser

// // Create express app
// const app = express();
// app.use(cors());
// app.use(bodyParser.json());


// // Set up multer storage for CSV file upload
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     cb(null, 'uploads/');
//   },
//   filename: (req, file, cb) => {
//     cb(null, Date.now() + path.extname(file.originalname));
//   }
// });

// // Initialize multer with storage settings
// const upload = multer({ storage: storage });

// //--------------------------------------------------------------API to upload CSV and store data in MySQL
// exports.uploadCSVFile = async ('/upload', upload.single('file'), (req, res) => {
//   if (!req.file) {
//     return res.status(400).send('No file uploaded.');
//   }

//   const filePath = req.file.path;

//   // Read and parse the CSV file
//   const results = [];
//   fs.createReadStream(filePath)
//     .pipe(parse({ columns: true, trim: true }))  // Parse the CSV file with headers
//     .on('data', (row) => {
//       console.log('Parsed row:', row);  // Log row data for debugging
//       results.push(row);
//     })
//     .on('end', () => {
//       // Insert data into MySQL
//       results.forEach((row) => {
//         const { Employee_Name, Employee_EmailID } = row;  // Use the correct field names here

//         if (!Employee_Name || !Employee_EmailID) {
//           console.error('Missing required fields in row:', row);
//           return; // Skip rows with missing data
//         }

//         const query = 'INSERT INTO participants (Employee_Name, Employee_EmailID) VALUES (?, ?)';
//         db.query(query, [Employee_Name, Employee_EmailID], (err, result) => {
//           if (err) {
//             console.error('Error inserting row:', err);
//           } else {
//             console.log('Inserted row:', result);
//           }
//         });
//       });

//       res.send('File uploaded and data saved to database.');
//     })
//     .on('error', (err) => {
//       res.status(500).send('Error reading CSV file.');
//     });
// });


// exports.getCSVFile = async ('/generateCSV', (req, res) => {
//     const query = 'SELECT * FROM participants';
  
//     db.query(query, (err, results) => {
//       if (err) {
//         console.error('Error fetching participants:', err);
//         return res.status(500).send('Error fetching data from database.');
//       }
  
//       // Log the results to the console
//       console.log('Participants data:', results);
  
//       // Optionally, you can return the results in the response to the client
//       res.json(results);
//     });
//   });

