const app = require('./app');
require('dotenv').config({ path: './config/.env' });


const port = process.env.PORT || 8000; // Use process.env.PORT or default to 8000





app.listen(port, () => {
  console.log(`Server is running on ${port}`);
});

// // Start the server
// app.listen(5000, () => {
//   console.log('Server running on http://localhost:5000');
// });





