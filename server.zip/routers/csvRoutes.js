// const express = require('express');
// const router = express.Router();
// const {uploadCSVFile} = require('../controllers/gameController')


// router.post('/uploadCSV', uploadCSVFile);
// // router.get('/getProducts', getProducts, getProductsByCategory);


// module.exports = router;

const express = require('express');
const router = express.Router();
const { uploadCSVFile, getCSVFile, upload } = require('../controllers/gameController');

// Route to upload CSV file
router.post('/upload', upload.single('file'), uploadCSVFile);

// Route to get CSV data
router.get('/generateCSV', getCSVFile);

module.exports = router;
